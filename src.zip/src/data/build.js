module.exports = {
    env: process.env.ELEVENTY_ENV,
    timestamp: new Date()
}
